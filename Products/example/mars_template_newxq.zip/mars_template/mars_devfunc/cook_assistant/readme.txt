## 烹饪助手说明
如果cook_assistant下有新增目录(app),需要在mars_template/makefile中的app变量加入该目录下的c文件
框架说明见:语雀 https://iotmars.yuque.com/wnf7k5/xygr05/ubpt50cpo4dg7zdm?singleDoc#


## 提交记录
0829提交防干烧V0.1.3
0905提交代码：1、整理代码   2、dryburn_judge_temp取值范围的修改（适配下饺子后的误触情况）   3、获得最长非常平缓温度的时间戳修改