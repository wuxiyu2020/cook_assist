/*
 * @Description  : 
 * @Author       : zhoubw
 * @Date         : 2022-08-17 17:01:07
 * @LastEditors  : zhoubw
 * @LastEditTime : 2022-09-09 14:36:57
 * @FilePath     : /alios-things/Products/example/mars_template/mars_devfunc/mars_sterilizer.c
 */

#if MARS_STERILIZER

#include "mars_sterilizer.h"

void mars_sterilizer_uartMsgFromSlave(uartmsg_que_t *msg, 
                                mars_template_ctx_t *mars_template_ctx, 
                                uint16_t *index, bool *report_en, uint8_t *nak)
{

}

#endif