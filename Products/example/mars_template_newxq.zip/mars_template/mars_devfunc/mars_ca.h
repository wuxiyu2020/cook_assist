/*** 
 * @Description  : 
 * @Author       : zhoubw
 * @Date         : 2022-07-28 15:43:08
 * @LastEditors  : zhouxc
 * @LastEditTime : 2024-10-25 16:36:16
 * @FilePath     : /et70-ca3/Products/example/mars_template/mars_devfunc/mars_ca.h
 */
#ifndef __MARS_CA_H__
#define __MARS_CA_H__
#ifdef __cplusplus
extern "C" {
#endif

void mars_ca_init(void);


#ifdef __cplusplus
}
#endif
#endif